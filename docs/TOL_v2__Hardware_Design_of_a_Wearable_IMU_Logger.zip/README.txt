TOL v2: revised report
16 November 2026

The compiled report has 22 pages in total. The main body ends on page 13;
references occupy the remainder of page 13 and page 14; technical appendices
occupy pages 15-22.

The six main sections are Circuit Specification, Refined Specification,
System Block Diagram, Schematic Design, PCB Design and Bill of Materials.
The abstract, references and supporting technical appendices are retained.

This revision removes the requirement identifiers, coded operating profiles,
firmware-rule identifiers and requirement traceability appendix. The Results,
Discussion and Conclusion sections are removed. Relevant power, storage and
size calculations are included in the schematic and PCB sections. Wording
and table headings use descriptive terms, with no em dashes.

Standard schematic references (such as resistor R1), package pins (such as
F2), net names and register names remain because they identify real circuit
connections or settings. No circuit, PCB layout or measured result was changed.
The style reference was Tiny Open Logger by Toledano and Gilbert (2025).

Build with pdfLaTeX:
    latexmk -pdf main.tex
Alternatively upload the ZIP to Overleaf and select main.tex as the root file.
A full TeX Live installation with Libertine, NewTX and Inconsolata is needed.
The ACM class and bibliography style are included. Original class sources
are in template-source for licensing. Recheck the page count after edits.

Checks: compiled successfully, all references resolved, no overfull boxes,
complete 37-line BOM with 72 fitted parts, and rendered pages inspected.
The archive contains the report sources and figures, not editable CAD.
Report text was revised with AI assistance; original source provenance
comments are retained where present.
